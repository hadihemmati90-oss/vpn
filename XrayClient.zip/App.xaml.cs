using System.Windows;

namespace XrayClient
{
    public partial class App : Application
    {
    }
}
